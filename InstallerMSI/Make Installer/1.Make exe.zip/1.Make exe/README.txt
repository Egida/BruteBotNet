use :

1. Edit setup.py
2. python.exe setup.py build
